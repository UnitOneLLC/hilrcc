<?php
/**
 * GravityView default widgets and generic widget class
 *
 * @deprecated 1.7.5
 */

include_once( GRAVITYVIEW_DIR .'includes/widgets/class-gravityview-widget.php' );
