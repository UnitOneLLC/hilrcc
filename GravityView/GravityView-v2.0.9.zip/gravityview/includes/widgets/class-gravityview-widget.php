<?php
/**
 * Main GravityView widget class
 *
 * @deprecated Use \GV\Widget instead
 */
class GravityView_Widget extends \GV\Widget {
}
