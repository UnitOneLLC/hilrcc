<?php
/**
 * The default field output template.
 *
 * @global \GV\Template_Context $gravityview
 * @since 2.0
 */
echo $gravityview->display_value;
