<?php
/**
 * The footer for the output list.
 *
 * @global \GV\Template_Context $gravityview
 */
?>
	<?php gravityview_footer( $gravityview ); ?>
</div>
<?php gravityview_after( $gravityview ); ?>
