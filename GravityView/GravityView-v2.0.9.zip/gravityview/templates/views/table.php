<?php
/**
 * The table layout template
 *
 * @global \GV\Template_Context $gravityview
 */
	$gravityview->template->get_template_part( 'table/table', 'header' );
	$gravityview->template->get_template_part( 'table/table', 'body' );
	$gravityview->template->get_template_part( 'table/table', 'footer' );
