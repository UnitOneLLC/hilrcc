<?php
header("Location: /index.php/inbox-view", true, 302);
?>