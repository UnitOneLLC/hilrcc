<?php



	/**
 	 Class Name: SP Gravity Forms Documents
	 Class URI: http://specialpress.de/plugins/spgfdoc
	 Description: Use Gravity Forms as Front-End to fill Microsoft Word Documents
	 Version: 1.4.0
	 Date: 2017/12/10
	 Author: Ralf Fuhrmann
	 Author URI: http://naranili.de
	 */



	class SpGfDocuments extends GFFeedAddOn 
	{

	
		protected $_version = '1.5.0';
		protected $_min_gravityforms_version = '2.0.0';
		protected $_slug = 'documents';
		protected $_path = 'gravityforms_documents/gravityforms_documents.php';
		protected $_full_path = __FILE__;
		protected $_title = 'Gravity Forms Documents';
		protected $_short_title = 'GF Documents';

		private static $_instance = null;



		/**
		 * get an instance of this class.
		 *
		 * @return GFSimpleAddOn
		 */

		public static function get_instance() 
		{
		
			
			if ( self::$_instance == null ) 
				self::$_instance = new SpGfDocuments();
		

			return( self::$_instance );


		}	



		/**
		 * plugin starting point
		 * handles hooks, loading of language files and PayPal delayed payment support
		 */

		public function init() 
		{

		
			parent::init();


			/**
			 * load the textdomain
			 */

			if( function_exists('load_plugin_textdomain') )
				load_plugin_textdomain( 'spgfdocs', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/');


			/**
			 * add GF actions
			 */


		
		
			/**
			 * add GF filters
			 */

			add_filter( 'gform_custom_merge_tags', array( &$this, 'spgfdocs_gform_custom_merge_tags' ), 10, 3 );
			add_filter( 'gform_replace_merge_tags', array( &$this, 'spgfdocs_gform_replace_merge_tags' ), 10, 7 );
			add_filter( 'gform_notification_ui_settings', array( &$this, 'spgfdocs_gform_notification_ui_settings' ), 10, 3 );		
			add_filter( 'gform_pre_notification_save', array( &$this, 'spgfdocs_gform_pre_notification_save' ), 10, 2 );
			add_filter( 'gform_notification', array( &$this, 'spgfdocs_gform_notification' ), 10, 3 );


		}



		/**
		 * process the feed 
		 *
		 * @param array $feed the feed object to be processed
		 * @param array $entry the entry object currently being processed
		 * @param array $form the form object currently being processed
		 *
		 * @return bool|void
		 */

		public function process_feed( $feed, $entry, $form ) 
		{
		

			/* include the libs */
		
			require_once 'bootstrap.php';

			//\PhpOffice\PhpWord\Settings::setPdfRendererPath( trailingslashit( plugin_dir_path(__FILE__) ) . 'vendor/TCPDF' );
			//\PhpOffice\PhpWord\Settings::setPdfRendererName( 'TCPDF' );


			/* load the template file */ 

			$templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor( $feed[ 'meta' ][ 'templateFile' ] );

			/* process the used datafields */

			foreach( $feed[ 'meta' ][ 'templateFields' ] AS $field )
			{


				$entry_field = RGFormsModel::get_field( $form, $field[ 'value' ] );
				
				$entry_value = $this->get_field_value( $form, $entry, $field[ 'value' ] );

				$templateProcessor->setValue( $field[ 'custom_key' ], GFCommon::get_lead_field_display( $entry_field, $entry_value, $entry[ 'currency' ] ) );


			}


			/* save the templated file */

			$templateProcessor->saveAs( trailingslashit( plugin_dir_path(__FILE__) ) . 'documents/document_' . sha1( $entry[ 'id' ] . '-' . $feed[ 'id' ] ) . '.docx' );


		}




		/**
		 * --------------------------------------------------------------------------------
		 * filters and actions to extend the GF functions
		 * --------------------------------------------------------------------------------
		 */




		/**
		 * return an array of the columns to display
		 *
		 * @return array
		 */

		public function feed_list_columns() 
		{
    
		
			return( array(
				'feedName' => esc_html__( 'Feed Name', 'spgfdocs' ),
				'templateFile' => esc_html__( 'Template File', 'spgfdocs' )
			) );


		}



		/**
		 * configures the settings which should be rendered on the feed edit page in the form settings
		 *
		 * @return array
		 */

		public function feed_settings_fields() 
		{


			$settingFields = array();


			$settingFields[ 'default' ] = array(
				
				'title'  => esc_html__( 'Default Document Fields', 'spgfdocs' ),
				'description' => '',
				'fields' => array(

						array(
							'label'   	=> esc_html__( 'Feed name', 'spgfdocs' ),
							'type'   	=> 'text',
							'name'    	=> 'feedName',
							'class'		=> 'medium',
							'tooltip' 	=> esc_html__( 'Enter a name for the feed', 'spgfdocs' ),
							'required'	=> true,
						),

						array(
							'label'     => esc_html__( 'Template Filename', 'spgfdocss' ),
							'name'      => 'templateFile',
							'tooltip'	=> esc_html__( 'Enter the name and path of your uploaded Template file', 'spgfdocss' ),
							'type'    	=> 'feed_file_upload',
							'class'   	=> 'large',
							'save_callback' => array( &$this, 'handle_file_upload_save' )
						),

					),

				);


			$settingFields[ 'mapping' ] = array(

				'title'  => esc_html__( 'Template Fields', 'spgfdocs' ),
				'fields' => array(

					array(
						'name'                => 'templateFields',
						'label'               => esc_html__( 'Template Fields', 'spgfdocs' ),
						'type'                => 'dynamic_field_map',
						'limit'               => 200,
						'tooltip'             => esc_html__( 'Add the Template Fields you need to map to your Form Fields', 'spgfdocs' ),

					),
    
				),

			);
				
			return( array_values( $settingFields ) );


		}



		/**
		 * display a file upload field
		 *
		 * @param array $field the field object currently being processed
		 *
		 * @return bool|void
		 */

		public function settings_plugin_file_upload( $field )
		{
    

			$attributes = $this->get_field_attributes( $field );
			$default_value = rgar( $field, 'value' ) ? rgar( $field, 'value' ) : rgar( $field, 'default_value' );
			$value = $this->get_setting( $field[ 'name' ], $default_value );


			if( isset( $_POST[ '_gaddon_setting_' . $field[ 'name' ] ] ) )
				$value = $_POST[ '_gaddon_setting_' . $field['name' ] ];


			?>
			<input type="text" name="_gaddon_setting_<?php echo $field[ 'name' ]; ?>" value="<?php echo $value; ?>" <?php echo implode( ' ', $attributes ); ?> readonly />
			<input type="file" name="_gaddon_setting_<?php echo $field[ 'name' ]; ?>_upload" id="<?php echo $field[ 'name' ]; ?>" class="<?php echo $field[ 'class' ]; ?>" />
			<script type="text/javascript">
				jQuery(document).ready(function(){
					jQuery('input[name=_gaddon_setting_<?php echo $field[ 'name']; ?>_upload]').closest('form').attr('enctype', 'multipart/form-data');
				});
			</script>
			<?php
  

		}



		/**
		 * display a file upload field
		 *
		 * @param array $field the field object currently being processed
		 *
		 * @return bool|void
		 */

		public function settings_feed_file_upload( $field )
		{


			$attributes = $this->get_field_attributes( $field );
			$default_value = rgar( $field, 'value' ) ? rgar( $field, 'value' ) : rgar( $field, 'default_value' );
			$value = $this->get_setting( $field[ 'name' ], $default_value );


			if( isset( $_POST[ '_gaddon_setting_' . $field[ 'name' ] ] ) )
				$value = $_POST[ '_gaddon_setting_' . $field[ 'name' ] ];


			?>
			<input type="text" name="_gaddon_setting_<?php echo $field[ 'name' ]; ?>" value="<?php echo $value; ?>" <?php echo implode( ' ', $attributes ); ?> readonly />
			<input type="file" name="_gaddon_setting_<?php echo $field[ 'name' ]; ?>_upload" <?php echo implode( ' ', $attributes ); ?> />
			<?php echo rgar( $field, 'after_input' ); ?>
			<script type="text/javascript">
				jQuery(document).ready(function(){
					jQuery('input[name=_gaddon_setting_<?php echo $field['name']; ?>_upload]').closest('form').attr('enctype', 'multipart/form-data');
				});
			</script>
			<?php
  

		}



		/**
		 * save the field value for a file upload field
		 *
		 * @param array $field the field object currently being processed
		 * @param array $field_setting the settings of the currently processed field
		 *
		 * @return string 
		 */

		public function handle_file_upload_save( $field, $field_setting )
		{
    

			$upload = wp_handle_upload( $_FILES[ '_gaddon_setting_' . $field[ 'name' ] . '_upload' ], array( 'test_form' => false ) );

			if( $upload[ 'file' ] )
				$_POST[ '_gaddon_setting_' . $field[ 'name' ] ] = $upload[ 'file' ];
			else
				$_POST[ '_gaddon_setting_' . $field[ 'name' ] ] = $field_setting;


			return( $_POST[ '_gaddon_setting_' . $field[ 'name' ] ]  );
  

		}



		/**
		 * --------------------------------------------------------------------------------
		 * filters and actions to extend the GF functions
		 * --------------------------------------------------------------------------------
		 */



		/**
		 * replace the placeholder at a field with the right value
		 *
		 * @param $value mixed the field value
		 * @param $lead object the current entry
		 * @param $field object the current field
		 * @param $form object the current form
		 * @param $input_id string the id of the input
		 *
		 * @return array
		 */

		function spgfdocs_gform_replace_merge_tags( $text, $form, $entry, $url_encode, $esc_html, $nl2br, $format )
		{
			

			/* check if we need to replace a merge tag */

			if( ( strpos( $text, '{gfdocs:documentnames}' ) === false && strpos( $text, '{gfdocs:documentlinks}' ) === false ) || empty( $entry ) || empty( $form ) )
				return( $text );
   

			/* get the feeds for this form */

			$feeds = GFAPI::get_feeds( NULL, $form[ 'id' ], $this->_slug );

			/* return if we got an error object */

			if( is_object( $feeds ) )
				return( $text );
			

			/* loop thru the feeds */

			foreach( $feeds AS $feed )
			{

			
				/* check if there is a document to attach */

				$filename = trailingslashit( plugin_dir_path(__FILE__) ) . 'documents/document_' . sha1( $entry[ 'id' ] . '-' . $feed[ 'id' ] ) . '.docx';				
		
				if( is_file( $filename ) )
				{

					$mergeDocumentNames .= '<br />' . plugin_dir_path( __FILE__ ) . '/documents/document_' . sha1( $entry[ 'id' ] . '-' . $feed[ 'id' ] ) . '.docx';
					$mergeDocumentLinks .= '<a href="' . plugin_dir_url( __FILE__ ) . 'documents/document_' . sha1( $entry[ 'id' ] . '-' . $feed[ 'id' ] ) . '.docx' . '" target="_blank" >Document_' . sha1( $entry[ 'id' ] . '-' . $feed[ 'id' ] ) . '.docx</a>';


				}


			}


			/* replace the merge tag with the created filenames */

			if( $mergeDocumentNames )
				$text = str_replace( '{gfdocs:documentnames}', $mergeDocumentNames, $text );

			/* replace the merge tag with the created image links */
			
			if( $mergeDocumentLinks )
				$text = str_replace( '{gfdocs:documentlinks}', $mergeDocumentLinks, $text );
	
				
			return( $text );
			
			
		}


				
		/**
		 * add some nice and new merge tags to fill with needed data
		 *
		 * @param $form_id int the form id
		 * @param $fields object the fields
		 * @param $element_id int the id of the element
		 *
		 * @return array
		 */

		function spgfdocs_gform_custom_merge_tags( $form_id, $fields, $element_id )
		{			
				

			$custom_group[] = array( 'tag' => '{gfdocs:documentnames}', 'label' => __( 'Documents : Document Names', 'spgfdocs' ) );
			$custom_group[] = array( 'tag' => '{gfdocs:documentlinks}', 'label' => __( 'Documents : Document Links', 'spgfdocs' ) );

			return( $custom_group );

					
		}



		/**
		 * extend the notification settings to attache the templated document at the notification eMail
		 *
		 * @param $ui_settings array the current settings
		 * @param $notification array the notification array
		 * @param $form object the form object
		 *
		 * @return array
		 */

		function spgfdocs_gform_notification_ui_settings( $ui_settings, $notification, $form )
		{

	
			/* get the feeds for this form */

			$feeds = GFAPI::get_feeds( NULL, $form[ 'id' ], $this->_slug );


			/* return if we got an error object */

			if( is_object( $feeds ) )
				return( $ui_settings );
			

			/* loop thru the feeds */

			foreach( $feeds AS $feed )
			{


				$notificationFeed = rgar( $notification, 'spgfdocs_notification_feed_' . $feed[ 'id' ] );

				$checked = '';
				if( $notificationFeed )
					$checked = ' checked="checked"';

				$ui_settings[ 'spgfdocs_notification_setting' ] .= '
					<tr>
						<th><label for="spgfdocs_notification_feed_' . $feed[ 'id' ] . '">' . __( "Attach", 'spgfdocs' ) . ' ' . $feed[ 'meta' ][ 'feedName' ] . '</label></th>
						<td><input type="checkbox" name="spgfdocs_notification_feed_' . $feed[ 'id' ] . '" value="yes"' . $checked . '/></td>
					</tr>';


			}

			return( $ui_settings );		

	
		}

		
		
		/**
		 * save the extend notification settings
		 *
		 * @param $notification array the notification array
		 * @param $form object the form object
		 *
		 * @return array
		 */

		function spgfdocs_gform_pre_notification_save( $notification, $form ) 
		{


			/* get the feeds for this form */

			$feeds = GFAPI::get_feeds( NULL, $form[ 'id' ], $this->_slug );

			/* return if we got an error object */

			if( is_object( $feeds ) )
				return( $notification );
			

			/* loop thru the feeds */

			foreach( $feeds AS $feed )
				$notification[ 'spgfdocs_notification_feed_' . $feed[ 'id' ] ] = rgpost( 'spgfdocs_notification_feed_' . $feed[ 'id' ] );


			return( $notification );


		}
		
		
		
		/**
		 * process the notification and add the templated document as an attachement
		 *
		 * @param $notification array the notification array
		 * @param $form object the form object
		 * @param $entry object the entry object
		 *
		 * @return array
		 */

		function spgfdocs_gform_notification( $notification, $form, $entry ) 
		{


			/* get the feeds for this form */

			$feeds = GFAPI::get_feeds( NULL, $form[ 'id' ], $this->_slug );

			/* return if we got an error object */

			if( is_object( $feeds ) )
				return( $notification );
			

			/* loop thru the feeds */

			foreach( $feeds AS $feed )
			{


				/* check if the file should be attached */
			
				if( $notification[ 'spgfdocs_notification_feed_' . $feed[ 'id' ] ] == 'yes' )
				{				

				
					/* check if there is a file to attach */
				
					$filename = trailingslashit( plugin_dir_path(__FILE__) ) . 'documents/document_' . sha1( $entry[ 'id' ] . '-' . $feed[ 'id' ] ) . '.docx';
			
					if( is_file( $filename ) )
						$notification[ 'attachments' ][] = $filename;

				}

			}


			return( $notification );
			
			
		}	



	}
