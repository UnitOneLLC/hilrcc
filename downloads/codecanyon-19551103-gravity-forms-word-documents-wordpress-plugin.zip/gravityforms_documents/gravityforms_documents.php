<?php


	/**
 	 Plugin Name: SP Gravity Forms Documents
	 Plugin URI: http://specialpress.de/plugins/spgfdoc
	 Description: Use Gravity Forms as Front-End to fill Microsoft Word Documents
	 Version: 1.5.0
	 Date: 2017/12/10
	 Author: Ralf Fuhrmann
	 Author URI: http://naranili.de
	 */

	
	
	/**
	 * Changes
	 * -------
	 *
	 * updated to the latest phpOffice/phpWord lib
	 * now the output values are formatted as from the gravity forms general or form settings
	 *
	 */
	 
	 
	
	/**
	 * To Do
	 * -----
	 *
	 * add translation 
	 * update documentation
	 *
	 */
	 
	
	
	if( !isset( $_SESSION ) )
		session_start();
	
    error_reporting( E_ERROR );
	
	
	
	/**
	 * check if GF is active and include common classes
	 */
	


	if ( class_exists( 'GFForms' ) )
	{


		GFAddOn::register( 'SpGfDocuments' );	

		GFForms::include_feed_addon_framework();



		/**
		 * check and maybe load the plugin class
		 */

		if( !class_exists( 'SpGfDocuments' ) ) 
			require_once( 'class.gravityforms_documents.php' );
	

	}

	
	
	/**
	 * if we are lesser than PHP 5.5 we have to
	 * create a function array_column
	 */

	if( !function_exists( 'array_column' ) )
	{

		function array_column( $array, $column_name )
		{

			return array_map( function( $element ) use( $column_name ){return $element[ $column_name ];}, $array );

		}

	}	



?>