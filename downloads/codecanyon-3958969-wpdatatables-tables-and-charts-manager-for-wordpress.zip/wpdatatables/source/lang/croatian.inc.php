{
    "sProcessing":   "Procesiram...",
    "sLengthMenu":   "Prikaži _MENU_ rezultata po stranici",
    "sZeroRecords":  "Ništa nije pronađeno",
    "sInfo":         "Prikazano _START_ do _END_ od _TOTAL_ rezultata",
    "sInfoEmpty":    "Prikazano 0 do 0 od 0 rezultata",
    "sInfoFiltered": "(filtrirano iz _MAX_ ukupnih rezultata)",
    "sInfoPostFix":  "",
    "sSearch":       "Filter",
    "sUrl": "",
    "oPaginate": {
        "sFirst":    "Prva",
        "sPrevious": "Nazad",
        "sNext":     "Naprijed",
        "sLast":     "Zadnja"
    }
}
