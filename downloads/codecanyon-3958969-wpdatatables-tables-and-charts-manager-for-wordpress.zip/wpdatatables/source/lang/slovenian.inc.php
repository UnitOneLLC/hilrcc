{
    "sProcessing":   "Obdelujem...",
    "sLengthMenu":   "Prikaži _MENU_ zapisov",
    "sZeroRecords":  "Noben zapis ni bil najden",
    "sInfo":         "Prikazanih od _START_ do _END_ od skupno _TOTAL_ zapisov",
    "sInfoEmpty":    "Prikazanih od 0 do 0 od skupno 0 zapisov",
    "sInfoFiltered": "(filtrirano po vseh _MAX_ zapisih)",
    "sInfoPostFix":  "",
    "sSearch":       "Išči:",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "Prva",
        "sPrevious": "Nazaj",
        "sNext":     "Naprej",
        "sLast":     "Zadnja"
    }
}
