\section intro Who this documentation is for

This documentation is for _developers_, not for non-developers. If you don't intend to edit any code, then you should instead visit the [GravityView Support & Knowledgebase](http://docs.gravityview.co).

If you have any questions about the code, please [email GravityView support](mailto:support@gravityview.co) and we'll get back to you.

This manual is divided in the following sections:

### GravityView WordPress Hooks

- \ref filters "Filters"
- \ref actions "Actions"