<?php
/**
 * Display a note, without editing options
 *
 * @since 1.17
 */
?>
<tr class="{row_class}">
	<td class="entry-detail-note">
		{note_detail}
	</td>
</tr>