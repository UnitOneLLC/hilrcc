<?php

define('HILRCC_PROPOSAL_FORM_ID', '2');
define('HILRCC_VIEW_ID_CATALOG', '201');
define('HILRCC_VIEW_ID_GLANCE', '426');
define('HILRCC_FIELD_ID_TITLE', '1');
define('HILRCC_FIELD_ID_STATUS', '37');
define('HILRCC_FIELD_ID_DURATION', '3');
define('HILRCC_FIELD_ID_TIMESLOT', '55');
define('HILRCC_FIELD_ID_CHOICE_1', '38');
define('HILRCC_FIELD_ID_CHOICE_2', '40');
define('HILRCC_FIELD_ID_CHOICE_3', '39');
define('HILRCC_FIELD_ID_PHONE_1', '46');
define('HILRCC_FIELD_ID_PHONE_2', '50');
define('HILRCC_FIELD_ID_DISCUSSION', '36');
define('HILRCC_FIELD_ID_READINGS_STRING', '64');
define('HILRCC_FIELD_ID_BOOKS', '14');
define('HILRCC_FIELD_ID_SGL1_FIRST', '56.3');
define('HILRCC_FIELD_ID_SGL1_LAST', '56.6');
define('HILRCC_FIELD_ID_SGL1_BIO', '18');
define('HILRCC_FIELD_ID_SGL2_FIRST', '57.3');
define('HILRCC_FIELD_ID_SGL2_LAST', '57.6');
define('HILRCC_FIELD_ID_SGL2_BIO', '19');
define('HILRCC_FIELD_ID_COURSE_NO', '42');

define('HILRCC_STEP_ID_REV_BY_COMM', '13');

define('HILRCC_LABEL_AUTHOR', 'Author (first last)');
define('HILRCC_LABEL_TITLE', 'Title');
define('HILRCC_LABEL_PUBLISHER', 'Publisher');
define('HILRCC_LABEL_EDITION', 'Edition and Date');
define('HILRCC_LABEL_ONLY_ED', 'Only this edition (Y/N)');
define('HILRCC_TAG_BOLD_OPEN', '<strong>');
define('HILRCC_TAG_BOLD_CLOSE', '</strong>');

function HILRCC_enqueue_styles()
{
    
    /* $parent_style = 'twentyseventeen-style'; */
    $parent_style = 'gravityflow_status';
    
    wp_enqueue_style($parent_style, get_template_directory_uri() . '/style.css');
    wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/style.css', array(
        $parent_style
    ), wp_get_theme()->get('Version'));
    
    wp_register_script('hilrpropjs', get_stylesheet_directory_uri() . '/hilrprop.js', array(
        'jquery'
    ));
    wp_enqueue_script('hilrpropjs');
    
    wp_localize_script('hilrpropjs', 'HILRCC_ajax_map', array(
        'ajaxURL' => admin_url('admin-ajax.php')
    ));
    
}
add_action('wp_enqueue_scripts', 'HILRCC_enqueue_styles');

/* Function to create a shortcode for the URL of the Inbox page */
function HILRCC_show_inbox_url($atts)
{
    
    $formid       = 0;
    $entryid      = 0;
    $have_formid  = false;
    $have_entryid = false;
    
    if (is_array($atts) and array_key_exists('formid', $atts)) {
        $formid      = $atts['formid'];
        $have_formid = ($formid != 0);
    }
    
    if (is_array($atts) and array_key_exists('entryid', $atts)) {
        $entryid      = $atts['entryid'];
        $have_entryid = ($entryid != 0);
    }
    if (have_formid === false) {
        return esc_url(site_url() . '/index.php/inbox/');
    }
    if (have_entryid === false) {
        return site_url() . '/index.php/inbox/?page=gravityflow-inbox&view=entry&id=' . $formid;
    }
    
    return site_url() . '/index.php/inbox/?page=gravityflow-inbox&view=entry&id=' . $formid . '&lid=' . $entryid;
}
add_shortcode('HILRCC_inbox_url', 'HILRCC_show_inbox_url');

/* Function to create a shortcode for the URL of the Proposal View page */
function HILRCC_show_proposal_view_url($atts)
{
    $entryid      = 0;
    $have_entryid = false;
    if (is_array($atts) and array_key_exists('entryid', $atts)) {
        $entryid      = $atts['entryid'];
        $have_entryid = ($entryid != 0);
    }
    
    if ($have_entryid) {
        return site_url() . '/index.php/proposal-view/entry/' . $entryid;
    }
    return site_url() . '/index.php/proposal-view';
}
add_shortcode('HILRCC_proposal_view_url', 'HILRCC_show_proposal_view_url');

/* Function to create a shortcode for the URL of the Voting Review page */
function HILRCC_show_voting_review_url($atts)
{
    $entryid      = 0;
    $have_entryid = false;
    if (is_array($atts) and array_key_exists('entryid', $atts)) {
        $entryid      = $atts['entryid'];
        $have_entryid = ($entryid != 0);
    }
    
    if ($have_entryid) {
        return site_url() . '/index.php/voting-review/entry/' . $entryid;
    }
    return site_url() . '/index.php/voting-review';
}
add_shortcode('HILRCC_voting_review_url', 'HILRCC_show_voting_review_url');

/**
 * Bypass Force Login for course proposal form
 *
 * @return bool Whether to disable Force Login. Default false.
 */
function my_forcelogin_bypass($bypass)
{
    $url         = $_SERVER['REQUEST_URI'];
    $is_form_url = is_numeric(strpos($url, '/course-proposal-form'));
    return ($is_form_url or is_front_page());
}
add_filter('v_forcelogin_bypass', 'my_forcelogin_bypass', 10, 1);

/* default to inbox after login */
function default_to_inbox($redirect_to)
{
    
    if (strcmp($redirect_to, site_url("wp-admin/")) === 0) {
        return '/index.php/inbox';
    }
    return $redirect_to;
}
add_filter('login_redirect', 'default_to_inbox');

/**
 * Hide the nav menu on the homempage
 */
add_filter('pre_wp_nav_menu', 'HILRCC_hide_menu_on_homepage');
function HILRCC_hide_menu_on_homepage($menu)
{
    if (is_home() or is_front_page()) {
        $menu = '';
    }
    return $menu;
}

/* add the action for the AJAX call for adding a comment */
add_action('wp_ajax_add_comment', 'add_comment');
function add_comment()
{
    if (!current_user_can('gravityforms_edit_entries')) {
        echo ("ERROR: capability");
        return;
    }
    
    $comment = stripslashes_deep($_POST["text"]);
    if ($comment == '') {
        echo ('EMPTY');
        return;
    }
    $entry_id = $_POST["entryId"];
    if ($entry_id == '') {
        echo ("ERROR: entry id missing");
        return;
    }
    
    $entry = GFAPI::get_entry($entry_id);
    if (is_wp_error($entry)) {
        echo ("ERROR: " . $entry . get_error_message());
        return;
    }
    
    $form      = GFAPI::get_form(HILRCC_PROPOSAL_FORM_ID);
    $discfield = GFFormsModel::get_field($form, HILRCC_FIELD_ID_DISCUSSION);
    $discvalue = $discfield->get_value_save_entry($comment, $form, $input_name = '', $entry_id, $entry);
    $result    = GFAPI::update_entry_field($entry_id, HILRCC_FIELD_ID_DISCUSSION, $discvalue);
    
    if ($result) {
        echo ("SUCCESS");
    } else {
        echo ("FAIL: GFAPI");
    }
}

/**
 * Validate fields, including email field on submit
 *
 * @return array('is_valid'=>bool, 'message'=>string)
 */
function HILRCC_validate_field($result, $value, $form, $field)
{
    /**
    if (($field->adminLabel == 'sgl_1_email') or ($field->adminLabel == 'sgl_2_email')) {
    if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
    $result['is_valid'] = false;
    $result['message'] = $value . ' is not a valid email address';
    }
    }
    **/
    if (($field->adminLabel == 'sgl_1_phone') or ($field->adminLabel == 'sgl_2_phone')) {
        if (!HILRCC_validate_phone($value)) {
            $result['is_valid'] = false;
            $result['message']  = $value . ' is not a valid phone number';
        }
    }
    return $result;
}
#add_filter( 'gform_field_validation', 'HILRCC_validate_field', 10, 4 );


add_filter('gform_validation', 'HILRCC_custom_validation');
function HILRCC_custom_validation($validation_result)
{
    $form   = $validation_result['form'];
    $c1     = rgpost('input_' . HILRCC_FIELD_ID_CHOICE_1);
    $c2     = rgpost('input_' . HILRCC_FIELD_ID_CHOICE_2);
    $c3     = rgpost('input_' . HILRCC_FIELD_ID_CHOICE_3);
    $phone1 = rgpost('input_' . HILRCC_FIELD_ID_PHONE_1);
    $phone2 = rgpost('input_' . HILRCC_FIELD_ID_PHONE_2);
    
    if ($c1 != $c2) {
        $c2_ok = true;
    } else {
        $c2_ok = false;
    }
    if (($c1 != $c3) and ($c2 != $c3)) {
        $c3_ok = true;
    } else {
        $c3_ok = false;
    }
    $phone1_ok = HILRCC_validate_phone($phone1);
    if (($phone2 != NULL) and ($phone2 != '')) {
        $phone2_ok = HILRCC_validate_phone($phone2);
    } else {
        $phone2_ok = true;
    }
    
    if ($c2_ok and $c3_ok and $phone1_ok and $phone2_ok) {
        $validation_result['is_valid'] = true;
        return $validation_result;
    }
    
    // set the form validation to false
    $validation_result['is_valid'] = false;
    
    //finding Field with ID of 1 and marking it as failed validation
    foreach ($form['fields'] as &$field) {
        
        if (($field->id == HILRCC_FIELD_ID_CHOICE_2) and (!$c2_ok)) {
            $field->failed_validation  = true;
            $field->validation_message = 'Second choice cannot be the same as first.';
        }
        
        if (($field->id == HILRCC_FIELD_ID_CHOICE_3) and (!$c3_ok)) {
            $field->failed_validation  = true;
            $field->validation_message = 'Third choice cannot be the same as first or second.';
        }
        
        if (($field->id == HILRCC_FIELD_ID_PHONE_1) and (!$phone1_ok)) {
            $field->failed_validation  = true;
            $field->validation_message = 'Please enter a valid phone number.';
        }
        
        if (($field->id == HILRCC_FIELD_ID_PHONE_2) and (!$phone2_ok)) {
            $field->failed_validation  = true;
            $field->validation_message = 'Please enter a valid phone number.';
        }
    }
    
    //Assign modified $form object back to the validation result
    $validation_result['form'] = $form;
    return $validation_result;
}



function HILRCC_validate_phone($numberString)
{
    /*
    regex for North American phone number from
    https://stackoverflow.com/questions/3357675/validating-us-phone-number-with-php-regex
    */
    $sPattern = "/^
        (?:                                 # Area Code
            (?:                            
                \(                          # Open Parentheses
                (?=\d{3}\))                 # Lookahead.  Only if we have 3 digits and a closing parentheses
            )?
            (\d{3})                         # 3 Digit area code
            (?:
                (?<=\(\d{3})                # Closing Parentheses.  Lookbehind.
                \)                          # Only if we have an open parentheses and 3 digits
            )?
            [\s.\/-]?                       # Optional Space Delimeter
        )?
        (\d{3})                             # 3 Digits
        [\s\.\/-]?                          # Optional Space Delimeter
        (\d{4})\s?                          # 4 Digits and an Optional following Space
        (?:                                 # Extension
            (?:                             # Lets look for some variation of 'extension'
                (?:
                    (?:e|x|ex|ext)\.?       # First, abbreviations, with an optional following period
                |
                    extension               # Now just the whole word
                )
                \s?                         # Optionsal Following Space
            )
            (?=\d+)                         # This is the Lookahead.  Only accept that previous section IF it's followed by some digits.
            (\d+)                           # Now grab the actual digits (the lookahead doesn't grab them)
        )?                                  # The Extension is Optional
        $/x"; // /x modifier allows the expanded and commented regex
    
    return (preg_match($sPattern, $numberString) == 1);
}

/* change the Approve button in the Review by Committee step */
add_filter('gravityflow_approve_label_workflow_detail', 'filter_approve_label_workflow_detail', 10, 2);
function filter_approve_label_workflow_detail($approve_label, $step)
{
    if ($step->get_name() == "Review by Committee") {
        return 'Advance';
    } else {
        return "Approve";
    }
}

add_filter('gravityflow_revert_label_workflow_detail', 'filter_revert_label_workflow_detail', 10, 2);
function filter_revert_label_workflow_detail($approve_label, $step)
{
    if ($step->get_name() == "Review by Committee") {
        return "Edit";
    } else {
        return "Revert";
    }
}

add_filter('gravityflow_reject_label_workflow_detail', 'filter_reject_label_workflow_detail', 10, 2);
function filter_reject_label_workflow_detail($reject_label, $step)
{
    if ($step->get_name() == "Review by Committee") {
        return "Needs discussion";
    } else {
        return "Reject";
    }
}

/* login page customization */
function my_login_logo()
{
?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url(<?php
    echo get_stylesheet_directory_uri();
?>/images/hilr-shield.png);
		height:65px;
		width:320px;
		background-size: 80px 92px;
		background-repeat: no-repeat;
        	padding-bottom: 30px;
        }
    </style>
<?php
}
add_action('login_enqueue_scripts', 'my_login_logo');

/* In GravityView, display the label of a dropdown field value instead of its sorting value */
add_filter('gravityview/fields/select/output_label', '__return_true');

/* Attach filter to GravityView get_entries to enable custom sort for catalog view */
add_filter('gravityview_entries', 'HILRCC_custom_sort_get_entries');
function HILRCC_custom_sort_get_entries($entries)
{
    $view_id = GravityView_View::getInstance()->getViewId();
    if ($view_id == HILRCC_VIEW_ID_CATALOG) {
        try {
            usort($entries, catalog_comparator);
        }
        catch (Exception $e) {
            echo 'Catalog sorting error:: ', $e->getMessage(), "\n";
        }
    }
    else if ($view_id == HILRCC_VIEW_ID_GLANCE) {
        try {
            usort($entries, glance_comparator);
        }
        catch (Exception $e) {
            echo 'Catalog sorting error:: ', $e->getMessage(), "\n";
        }
    }

    
    return $entries;
}

$duration_map = array(
    "Full Term" => 1,
    "Full Term Delayed Start" => 1,
    "First Half" => 2,
    "Second Half" => 3,
    "Either First or Second Half" => 4
);

/* comparison function for catalog sort */
function catalog_comparator($a_entry, $b_entry)
{
    global $duration_map;
    
    $a_duration = $duration_map[$a_entry[HILRCC_FIELD_ID_DURATION]];
    $b_duration = $duration_map[$b_entry[HILRCC_FIELD_ID_DURATION]];
    if ($a_duration < $b_duration) {
        return -1;
    } elseif ($a_duration > $b_duration) {
        return 1;
    } else {
        $a_slot = $a_entry[HILRCC_FIELD_ID_TIMESLOT];
        $b_slot = $b_entry[HILRCC_FIELD_ID_TIMESLOT];
        if ($a_slot < $b_slot) {
            return -1;
        } elseif ($a_slot > $b_slot) {
            return 1;
        } else {
            $a_title = $a_entry[HILRCC_FIELD_ID_TITLE];
            $b_title = $b_entry[HILRCC_FIELD_ID_TITLE];
            if ($a_title < $b_title) {
                return -1;
            } elseif ($a_title > $b_title) {
                return 1;
            }
        }
    }
    return 0;
}

/* comparison function for glance view sort */
function glance_comparator($a_entry, $b_entry)
{
    $a_slot = $a_entry[HILRCC_FIELD_ID_TIMESLOT];
    $b_slot = $b_entry[HILRCC_FIELD_ID_TIMESLOT];
	$a_course_no = $a_entry[HILRCC_FIELD_ID_COURSE_NO];
	$b_course_no = $b_entry[HILRCC_FIELD_ID_COURSE_NO];

	if ($a_slot < $b_slot) {
		return -1;
	} elseif ($a_slot > $b_slot) {
		return 1;
	}  else {
		$result = strcmp($a_course_no, $b_course_no);
		return $result;
	}  
}


/** remove "Howdy" (https://premium.wpmudev.org/blog/add-remove-from-wordpress/) **/
add_filter('gettext', 'change_howdy', 10, 3);
function change_howdy($translated, $text, $domain)
{
    
    #    if (!is_admin() || 'default' != $domain)
    #        return $translated;
    
    if (false !== strpos($translated, 'Howdy'))
        return str_replace('Howdy', 'Welcome', $translated);
    
    return $translated;
}


/* adjust the status field of the form when completing the Review by Committee step (id=13) */
add_filter('gravityflow_step_complete', 'HILRCC_gravityflow_step_complete', 10, 4);
function HILRCC_gravityflow_step_complete($step_id, $entry_id, $form_id, $status)
{
    if ($step_id == HILRCC_STEP_ID_REV_BY_COMM) {
        $newFieldValue = NULL;
        $formStatus    = $_POST['gravityflow_approval_new_status_step_' . HILRCC_STEP_ID_REV_BY_COMM];
        if ($formStatus == 'rejected') {
            $newFieldValue = 'Under discussion';
        } else if ($formStatus == 'approved') {
            $newFieldValue = 'Active';
        }
        if ($newFieldValue != NULL) {
            $result = GFAPI::update_entry_field($entry_id, HILRCC_FIELD_ID_STATUS, $newFieldValue);
        }
    }
    /* for UI steps, update automatic fields */
    $api  = new Gravity_Flow_API($form_id);
    $step = $api->get_current_step(GFAPI::get_entry($entry_id));
    if (HILRCC_is_UI_step($step)) {
        HILRCC_update_automatic_fields($entry_id);
    }
}
/* return true if the passed step is a User Input step */
function HILRCC_is_UI_step($step)
{
    $step_type = $step->get_type();
    return $step_type == 'user_input';
}
/* synthetic fields are based on the values of other fields */
function HILRCC_update_automatic_fields($entry_id)
{
    HILRCC_update_readings($entry_id);
    HILRCC_auto_bold_sgl_names($entry_id);
}
/* update the Readings string for the catalog based on the Books field */

function HILRCC_update_readings($entry_id)
{
    
    $books         = unserialize(rgar(GFAPI::get_entry($entry_id), HILRCC_FIELD_ID_BOOKS));
    $readingString = "";
    if (!empty($books)) {
        $readingString = "<strong>Readings: </strong>";
    } else {
        return;
    }
    
    $isFirst = true;
    foreach ($books as $book) {
        if (!$isFirst) {
            $readingString = $readingString . "; ";
        }
        $isFirst = false;
        $edOnly  = strtoupper($book[HILRCC_LABEL_ONLY_ED]);
        if (strpos($edOnly, 'Y') !== false) {
            $readingString = $readingString . "This edition only: ";
        }
        
        $author = $book[HILRCC_LABEL_AUTHOR] . ", ";
        $title  = "<em>" . $book[HILRCC_LABEL_TITLE] . "</em>";
        $pubed  = " (" . $book[HILRCC_LABEL_PUBLISHER] . ", " . $book[HILRCC_LABEL_EDITION] . ")";
        
        $readingString = $readingString . $author . $title . $pubed;
    }
    
    if (!empty($readingString)) {
        $readingString = $readingString . ".";
    }
    
    $result = GFAPI::update_entry_field($entry_id, HILRCC_FIELD_ID_READINGS_STRING, $readingString);
    return $result;
}

/* add <strong> tags around SGL names in bios */
function HILRCC_auto_bold_sgl_names($entry_id)
{
    $entry = GFAPI::get_entry($entry_id);
    
    $sgl      = rgar($entry, HILRCC_FIELD_ID_SGL1_FIRST) . " " . rgar($entry, HILRCC_FIELD_ID_SGL1_LAST);
    $bold_sgl = HILRCC_TAG_BOLD_OPEN . $sgl . HILRCC_TAG_BOLD_CLOSE;
    $new_bio  = HILRCC_replace_if_not_present(rgar($entry, HILRCC_FIELD_ID_SGL1_BIO), $sgl, $bold_sgl);
    GFAPI::update_entry_field($entry_id, HILRCC_FIELD_ID_SGL1_BIO, $new_bio);
    
    $sgl      = rgar($entry, HILRCC_FIELD_ID_SGL2_FIRST) . " " . rgar($entry, HILRCC_FIELD_ID_SGL2_LAST);
    $bold_sgl = HILRCC_TAG_BOLD_OPEN . $sgl . HILRCC_TAG_BOLD_CLOSE;
    $new_bio = HILRCC_replace_if_not_present(rgar($entry, HILRCC_FIELD_ID_SGL2_BIO), $sgl, $bold_sgl);
    GFAPI::update_entry_field($entry_id, HILRCC_FIELD_ID_SGL2_BIO, $new_bio);
}

function HILRCC_replace_if_not_present($text, $old, $new)
{
    if (strpos($text, $new) === false) {
        $text = str_replace($old, $new, $text);
    }
    return $text;
}


?>