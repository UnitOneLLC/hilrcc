/* 
 * hilrprop.js
 * Copyright (c) 2018 HILR
 *
 * Client-side code for HILR Course proposal app
 */
var HILRCC = {
	THE_FORM_ID : 2,
	MOVECLASS_STEM : "hilr-movecell-",
	REMOVE_TH : "hilr-remove-th",
	COLSPAN_STEM : "hilr-colspan-",
	KEEP_TH : "hilr-keep-th",
	
	formIsDirty: false,
		
	onLoad: function() {
		/* if this is the home page, add a button to reset the form */
		if (window.location.pathname == "/" || window.location.pathname == "") {
			var footer = jQuery(".gform_footer");
			if (footer.length == 1) {
				var resetBtn = document.createElement("button");
				jQuery(resetBtn).text("Reset form").attr("type", "reset").attr("id", "hilr_reset_btn");
				footer.append(resetBtn);
				jQuery(resetBtn).click(HILRCC.confirmClearForm);
			}
		}
		jQuery("#gform_save_2_link").on("click", (function() {})());
	
		/* hide the delayed start option from January through June */
		var today = new Date();
		if (today.getMonth() < 6) { /* Jan is 0 */
			var idclass = ".gchoice_" + HILRCC.THE_FORM_ID + "_3_1";
			var delayStartOption = jQuery(".hilr-duration " + idclass); 
			if (delayStartOption) {
				delayStartOption.hide();
			}
		}
		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
		 This code is to inject a textarea and a button in the single item
		 view for adding comments on a proposal
		 */
		 var editLinkRow = jQuery(".hilr-edit-link");
		 if (editLinkRow.length) {
		 	var markup=
		 		"<th>Add a comment</th>" + 
		 		"<td>" + 
		 		"<textarea id='hilr_comment_input' rows='5' cols='80' class='hilr-comment-input'></textarea>" +
		 		"<button id='hilr_add_comment_btn' class='hilr-add-comment-button'>Submit</button>" +
		 		"<button id='hilr_discard_comment_btn' class='hilr-add-comment-button'>Discard and Go Back</button>" +
		 		"</td>";
		 
		 	editLinkRow.html(markup);
			jQuery("#hilr_add_comment_btn").click(HILRCC.handle_add_comment);
			jQuery("#hilr_discard_comment_btn").click(HILRCC.handle_discard_comment);
		 }
		 
		/* install the unload handler */
		var inputs = jQuery("input").not("[type='hidden']").not("[class*='admin']").add("textarea").not("#gravityflow-note");
		if ( inputs.length != 0 ) {
			jQuery(window).on("beforeunload", HILRCC.onUnload);
			inputs.change(function() {HILRCC.formIsDirty = true;});
			
			var submitBtn = jQuery("#gform_submit_button_2");
			if (submitBtn.length) {
				submitBtn.on("click", function() {HILRCC.formIsDirty = false;});
			}
			submitBtn = jQuery("#gravityflow_update_button");
			if (submitBtn.length) {
				submitBtn.on("click", function() {HILRCC.formIsDirty = false;});
			}			
		}
	
		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
		  This code is to contain a discussion thread in a scrolling div
		  so that it doesn't take up too much vertical real-estate. */
		  var discussionRow = jQuery(".hilr-view-discussion");
		  if (discussionRow.length) {
		  	var tcell = jQuery(discussionRow).children("td")[0];
		  	var contents = jQuery(tcell).html();
		  	contents = "<div class='hilr-discussion-scroller'>" + contents + "</div>";
		  	jQuery(tcell).html(contents);
		  }
		  		 
		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
  		  This code is to rearrange Gravity View tables in single entry mode.
  		 */
  		 var movers = jQuery("[class*=" + HILRCC.MOVECLASS_STEM +"]");
  		 for (var i=0; i < movers.length; ++i) {
  		 	var hilrcls = HILRCC.extractClassname(movers[i].className, HILRCC.MOVECLASS_STEM);
  		 	var dest = hilrcls.substr(HILRCC.MOVECLASS_STEM.length).split('-');
  		 	var sel = "tr.gv-field-" + HILRCC.THE_FORM_ID + "-" + dest[0];
  		 	var destRow = jQuery(sel);
  		 	var td = jQuery(movers[i]).children('td')[0];
  		 	destRow.append(jQuery(jQuery(td).remove()));
  		 	jQuery(movers[i]).hide();
  		 	
  		 	if (jQuery(movers[i]).hasClass(HILRCC.KEEP_TH)) {
				var th = jQuery(movers[i]).children('th')[0];
				jQuery(td).html("<b>" + jQuery(th).text() + "</b>: " + jQuery(td).text()); 
  		 	}
  		 }
  		 /* remove TH elements for rows that have class hilr-remove-th */
  		 var deadTHs = jQuery("." + HILRCC.REMOVE_TH + " th");
  		 for (var i=0; i < deadTHs.length; ++i) {
  		 	deadTHs[i].remove();
  		 }
  		 /* add colspan attributes per hilr-colspan-* classes */
  		 var addColspans = jQuery("[class*=" + HILRCC.COLSPAN_STEM +"]");
  		 for (var i=0; i < addColspans.length; ++i) {
  		 	var hilrcls = HILRCC.extractClassname(addColspans[i].className, HILRCC.COLSPAN_STEM);
  		 	var colspan = hilrcls.substr(HILRCC.COLSPAN_STEM.length);
  		 	jQuery(jQuery(addColspans[i]).children("td")[0]).prop("colspan", colspan);
		 }
		 
		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
		   This code is to make the radio groups for the 1st, 2nd, and
		   3rd time slots mutually exclusive, e.g. if the user checks
		   Tuesday PM for the 1st choice, then Tuesday PM is disabled
		   for the 2nd and 3rd choices 
		*/
		var onSchedClick = function(val, clickedGroup) {
			var clicked, others = Array(2);
			if (clickedGroup === 1) {
				clicked = jQuery('.hilr-sched-1 input[type=radio]');
				others[0] = jQuery('.hilr-sched-2 input[type=radio]');
				others[1] = jQuery('.hilr-sched-3 input[type=radio]');
			}
			else if (clickedGroup === 2) {
				clicked = jQuery('.hilr-sched-2 input[type=radio]');
				others[0] = jQuery('.hilr-sched-1 input[type=radio]');
				others[1] = jQuery('.hilr-sched-3 input[type=radio]');
			}
			else {
				clicked = jQuery('.hilr-sched-3 input[type=radio]');
				others[0] = jQuery('.hilr-sched-1 input[type=radio]');
				others[1] = jQuery('.hilr-sched-2 input[type=radio]');
			}
			
			for (var i = 0; i < clicked.length; ++i) {
				if (clicked[i].value == val) {
					others[0][i].disabled = true;
					others[1][i].disabled = true;
					others[0][i].checked = false;
					others[1][i].checked = false;
				}
				else {
					if (others[0][i].disabled && !others[1][i].checked) {
						others[0][i].disabled = false;
					}
					if (others[1][i].disabled && !others[0][i].checked) {
						others[1][i].disabled = false;
					}
				}
			}
			
		};
		
		/* initialize listeners for schedule choice radio buttons */
		jQuery('.hilr-sched-1 input[type=radio]').click(function() {onSchedClick(this.value, 1);});
		jQuery('.hilr-sched-2 input[type=radio]').click(function() {onSchedClick(this.value, 2);});
		jQuery('.hilr-sched-3 input[type=radio]').click(function() {onSchedClick(this.value, 3);});
		
		HILRCC.prepareView(HILRCC.getViewId());
        
    },
    extractClassname: function(classList, stem) {
		var clazzes = classList.split(' ');
		var hilrcls = "";
		for (var i=0; i < clazzes.length; ++i) {
			if (clazzes[i].indexOf(stem) == 0) {
				hilrcls = clazzes[i];
				break;
			}
		}
		return hilrcls;
    },
    
    handle_add_comment: function() {
    	var text = jQuery("#hilr_comment_input").val();
    	var path = location.href.split('/');
    	var entryId = path[path.length-1];
    	if (!entryId) entryId = path[path.length-2];
    
    	var data = {
			'action': 'add_comment',
			'entryId' : entryId,
			'text': text
		};

		jQuery.post(HILRCC_ajax_map.ajaxURL, data, function(response) {
			if (response.indexOf("SUCCESS") == 0) {
				HILRCC.formIsDirty = false;
				window.location.reload();
			}
			else if (response.indexOf("EMPTY") != 0) {
				alert("Sorry, there was a problem: " + response);
			}
		});

    },
    
    handle_discard_comment: function() {
    	var textarea = jQuery("#hilr_comment_input");
    	if ((textarea.val() == '') || window.confirm("Are you sure?")) {
    		HILRCC.formIsDirty = false;
	    	textarea.val("");
    		window.history.back();
    	}
    },
    
    onUnload: function() {
    	if (HILRCC.formIsDirty) {
    		return "You have unsaved input -- click Cancel to stay on page";
    	}
    	else {
    		return undefined;
    	}
    },
    
    confirmClearForm: function() {
    	HILRCC.formIsDirty = false;
    	return confirm('Do you really want to reset?');
    },
    
    /* GravityView pages have a custom widget on the multiple items view 
       that contains a span with class 'hilr-view-id'. The id of the span
       is the name of the view.
    */
    getViewId: function() {
    	var viewIdSpan = jQuery(".hilr-view-id");
    	if (viewIdSpan.length == 1) {
    		return viewIdSpan.attr("id");
    	}
    	else {
    		return null;
    	}
    },
    
    prepareView: function(viewId) {
    	if (viewId == 'at-a-glance') {
    		var items = jQuery(".gv-list-view");
    		var currentSlot = "";
    		for (var i=0; i < items.length; ++i) {
    			var item = jQuery(jQuery(items[i]).children(".gv-list-view-title")[0]);    			
    			var thisSlotDiv = item.children(".hilr-glance-slot")[0];
    			if (thisSlotDiv) {
    				var slot = jQuery(thisSlotDiv).text();
    				if (slot && (slot != currentSlot)) {
    					currentSlot = slot;
    					var headerDiv = document.createElement("div");
    					var durationDiv = item.children(".hilr-glance-duration")[0];
    					if (durationDiv) {
    						var durationMap = {
    							"Full Term": "hilr-glance-full",
    							"First Half": "hilr-glance-first",
    							"Second Half": "hilr-glance-second"
    						}
	    					var durVal = jQuery(durationDiv).text();
	    					var durClass = durationMap[durVal];
	    					if (durClass) {
	    						jQuery(headerDiv).addClass(durClass);
	    					}
    					}
    					jQuery(headerDiv).addClass("hilr-glanceview-header");
    					jQuery(headerDiv).text(slot);
    					item.before(headerDiv);
    				}
    			}
    		}
    	}
    }
        
};
		
jQuery(document).ready(HILRCC.onLoad);


